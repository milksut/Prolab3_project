﻿//220229035 altay_gök
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_y
{
    using Microsoft.VisualBasic.ApplicationServices;
    using System.Transactions;

    class Yedek_parca
    {
        internal string isim = "";
        internal Yedek_parca(string isim)
        {
            this.isim = isim;
        }
        internal int inventory = 0;
        public override string ToString()
        {
            return isim + " - " + Convert.ToString(inventory);
        }
    }
    class Donanim
    {
        internal string isim = "";
        internal Donanim(string name)
        {
            this.isim = name;
        }
        internal List<Yedek_parca> yedek_parcalar = new List<Yedek_parca>();
        public override string ToString()
        {
            return isim;
        }
    }
    class Model
    {
        internal string isim = "";
        internal List<Donanim> donanimlar = new List<Donanim>();
        internal Model(string isim)
        {
            this.isim = isim;
        }
        public override string ToString()
        {
            return isim;
        }
    }
    class Marka
    {
        internal string isim = "";
        internal List<Model> modeller = new List<Model>();
        internal Marka(string isim)
        {
            this.isim = isim;
        }
        public override string ToString()
        {
            return isim;
        }
    }
    class Kullanıci
    {
        internal string id = "0@nickname"; //3-yonetici 2-satici 1-musteri 0-sample value, if a id starts with 0 there is a bug
        internal string takma_isim = "";
        internal string isim = "";
        internal string email = "";
        internal string sifre = "";
        internal string telefon_no = "";
        
        internal Kullanıci(string takma_isim, string isim, string email, string sifre, string telefon_no)
        {
            this.takma_isim = takma_isim;
            this.isim = isim;
            this.email = email;
            this.sifre = sifre;
            this.telefon_no = telefon_no;
        }
    }
    class Yonetici : Kullanıci
    {
        Yonetici(string takma_isim, string isim, string email, string sifre, string telefon_no)
            : base(takma_isim, isim, email, sifre, telefon_no)
        {
            base.id = "3@" + takma_isim;
        }
    }
    class Satici : Kullanıci
    {
        internal Satici(string takma_isim, string isim, string email, string sifre, string telefon_no)
            : base(takma_isim, isim, email, sifre, telefon_no)
        {
            base.id = "2@" + takma_isim;
        }
    }
    class Musteri : Kullanıci
    {
        internal Musteri(string takma_isim, string isim, string email, string sifre, string telefon_no)
            : base(takma_isim, isim, email, sifre, telefon_no)
        {
            base.id = "1@" + takma_isim;
        }
    }
    class Invoice 
    {
        internal string part_name;
        internal string part_path;
        internal string customer;
        internal int amount;
        internal string status = "waiting";
        internal string date;
        public override string ToString()
        {
            string name = part_path.Replace("Brands/","");
            name = name.Replace(".txt", "");
            return name + " - " + Convert.ToString(amount);
        }
    }
    static class Setup_wizard
    {
        public static void UserInitializer()
        {
            if (Directory.Exists("Users"))
            {  
            }
            else
            {
                Directory.CreateDirectory("Users");


                File.Create("Users/altay2510tr.txt").Close();

                StreamWriter writer = new StreamWriter("Users/altay2510tr.txt");
                writer.AutoFlush = true; 
                writer.WriteLine("Thebestpassword!10");
                writer.WriteLine("3@altay2510tr");
                writer.WriteLine("altay gök");
                writer.WriteLine("altay@gmail.com");
                writer.WriteLine("111-111-1111");
                writer.Close();

                File.Create("Users/robooot.txt").Close();

                writer = new StreamWriter("Users/robooot.txt");
                writer.AutoFlush = true;
                writer.WriteLine("1fgxxxcs$Aew4t");
                writer.WriteLine("2@robooot");
                writer.WriteLine("şükrü fırat sarp");
                writer.WriteLine("FCODEFCODE3@GMAİL.COM");
                writer.WriteLine("111-111-1111");
                writer.Close();

                File.Create("Users/seller_bot_1.txt").Close();

                writer = new StreamWriter("Users/seller_bot_1.txt");
                writer.AutoFlush = true;
                writer.WriteLine("Bot-is-selling1");
                writer.WriteLine("2@seller_bot_1");
                writer.WriteLine("seller bot 1");
                writer.WriteLine("sellerbot1@gmail.com");
                writer.WriteLine("555-555-5555");
                writer.Close();

                File.Create("Users/myk.txt").Close();

                writer = new StreamWriter("Users/myk.txt");
                writer.AutoFlush = true;
                writer.WriteLine("Password*1");
                writer.WriteLine("1@myk");
                writer.WriteLine("melik yalçınkaya");
                writer.WriteLine("melik@gmail.com");
                writer.WriteLine("111-111-1111");
                writer.Close();

                File.Create("Users/DarkMemo.txt").Close();

                writer = new StreamWriter("Users/DarkMemo.txt");
                writer.AutoFlush = true;
                writer.WriteLine("Password*2");
                writer.WriteLine("1@DarkMemo");
                writer.WriteLine("mehmet fadıl boyacı");
                writer.WriteLine("mehmet@gmail.com");
                writer.WriteLine("111-111-1111");
                writer.Close();
                
                File.Create("Users/user_list.txt").Close();
                writer = new StreamWriter("Users/user_list.txt")
                {
                    AutoFlush = true
                };
                writer.WriteLine("5");
                writer.WriteLine("altay2510tr");
                writer.WriteLine("robooot");
                writer.WriteLine("seller_bot_1");
                writer.WriteLine("myk");
                writer.WriteLine("DarkMemo");
                writer.Close();
            }
        }
        internal static List<string> GetUsers() 
        {
            List<string> users = new List<string>();
            StreamReader reader = new StreamReader("Users/user_list.txt");
            int n = Convert.ToInt32(reader.ReadLine());
            for (int i = 0; i < n; i++) { users.Add(reader.ReadLine()); }
            reader.Close();
            return users;
        }
        internal static void Save_new_user(Kullanıci kullanıci, List<string> users) 
        {
            users.Add(kullanıci.takma_isim);
            StreamWriter writer = new StreamWriter("Users/user_list.txt");
            writer.AutoFlush = true;
            writer.WriteLine(users.Count);
            for (int i = 0;i < users.Count;i++) { writer.WriteLine(users[i]); }
            writer.Close();

            File.Create("Users/" + kullanıci.takma_isim + ".txt").Close();

            writer = new StreamWriter("Users/" + kullanıci.takma_isim + ".txt");
            writer.AutoFlush = true;
            writer.WriteLine(kullanıci.sifre);
            writer.WriteLine(kullanıci.id);
            writer.WriteLine(kullanıci.isim);
            writer.WriteLine(kullanıci.email);
            writer.WriteLine(kullanıci.telefon_no);
            writer.Close();
        }
        internal static void Delete_user(Kullanıci kullanıci, List<string> users) 
        {
            users.Remove(kullanıci.takma_isim);
            StreamWriter writer = new StreamWriter("Users/user_list.txt");
            writer.AutoFlush = true;
            writer.WriteLine(users.Count);
            for (int i = 0; i < users.Count; i++) { writer.WriteLine(users[i]); }
            writer.Close();

            File.Delete("Users/" + kullanıci.takma_isim + ".txt");
        }
        internal static void BrandInitializer() 
        {
            if (Directory.Exists("Brands")) { }
            else 
            {
                string[] brandlist = { "Toyota" , "Ford" , "Honda" , "Chevrolet" , "BMW" , "Mercedes-Benz", "Volkswagen" , "Tesla" , "Nissan" , "Audi" };
                string[] modellist = { "Camry", "Mustang", "Civic", "Silverado", "3 Series", "C-Class", "Golf", "Model S", "Altima", "A4" };
                string[] Donanimlist = { "Camry LE", "Camry XSE", "Mustang GT", "Mustang Mach-E", "Civic LX", "Civic Type R", "Silverado 1500", "Silverado HD",
                "330i", "M340i","C 300", "AMG C 63","Golf TSI", "Golf GTI","Model S Long Range", "Model S Plaid","Altima S", "Altima SR","A4 Premium", "S4"};
                string[] spare_partslist = {"Brake Pads", "Air Filter", "Oil Filter", "Spark Plugs", "Headlight Bulbs","Transmission Fluid", "Brake Rotors",
                    "Serpentine Belt", "Cabin Air Filter", "Wiper Blades","Exhaust System", "Suspension Struts", "Fuel Pump", "Ignition Coil", "Oxygen Sensor",
                    "Battery", "Electric Motor", "Charging Cable", "Brake Calipers", "Tire Pressure Sensors","Water Pump", "Alternator", "Thermostat", "Wheel Bearings",
                    "Timing Belt","Clutch Kit", "Turbocharger", "Control Arms", "Radiator Fan", "Fuel Injector","Power Steering Pump", "Tie Rod Ends", "Fuel Filter",
                    "Mass Air Flow Sensor", "Window Regulator","Transmission Mount", "Differential Fluid", "Turbocharger Intercooler", "Brake Master Cylinder",
                    "Exhaust Manifold","Ignition Control Module", "Drive Belt", "Fuel Pressure Regulator", "Oxygen Sensor", "Camshaft Position Sensor",
                    "Performance Brake Kit", "Suspension Springs", "Air Intake System", "Intercooler", "Oil Cooler Kit"};
                
                Directory.CreateDirectory("Brands");
                File.Create("Brands/Brands_list.txt").Close();
                StreamWriter writer = new StreamWriter("Brands/Brands_list.txt");
                writer.AutoFlush = true;
                writer.WriteLine("10");
                for (int i = 0; i < brandlist.Length; i++)
                {
                    writer.WriteLine(brandlist[i]);
                    Directory.CreateDirectory("Brands/"+ brandlist[i]);
                }
                writer.Close();
                for (int i = 0;i <brandlist.Length;i++) 
                {
                    File.Create("Brands/" + brandlist[i] + "/model_list.txt").Close();
                    writer = new StreamWriter("Brands/" + brandlist[i] + "/model_list.txt");
                    writer.AutoFlush = true;
                    writer.WriteLine("1");
                    writer.WriteLine(modellist[i]);
                    writer.Close();
                    Directory.CreateDirectory("Brands/" + brandlist[i] + "/" + modellist[i]);
                    File.Create("Brands/" + brandlist[i] + "/" + modellist[i] + "/donanim_list.txt").Close();
                    writer = new StreamWriter("Brands/" + brandlist[i] + "/" + modellist[i] + "/donanim_list.txt");
                    writer.AutoFlush = true;
                    writer.WriteLine("2");
                    for (int j = 0; j < 2; j++) 
                    {   
                        writer.WriteLine(Donanimlist[(i*2)+j]);
                    }
                    writer.Close();
                    for (int j = 0; j < 2; j++)
                    {
                        Directory.CreateDirectory("Brands/" + brandlist[i] + "/" + modellist[i] + "/"+ Donanimlist[(i * 2) + j]);
                        File.Create("Brands/" + brandlist[i] + "/" + modellist[i] + "/" + Donanimlist[(i * 2) + j] +"/spare_parts_list.txt").Close();
                        writer = new StreamWriter("Brands/" + brandlist[i] + "/" + modellist[i] + "/" + Donanimlist[(i * 2) + j] + "/spare_parts_list.txt");
                        writer.AutoFlush = true;
                        writer.WriteLine("5");
                        for(int k = 0; k < 5; k++) 
                        {
                            writer.WriteLine(spare_partslist[(i*2)+j*5+k]);
                        }
                        writer.Close();
                        for (int k = 0; k < 5; k++)
                        {
                            File.Create("Brands/" + brandlist[i] + "/" + modellist[i] + "/" + Donanimlist[(i * 2) + j] + "/"+ spare_partslist[(i * 2) + j * 5 + k]+".txt").Close();
                            writer = new StreamWriter("Brands/" + brandlist[i] + "/" + modellist[i] + "/" + Donanimlist[(i * 2) + j] + "/" + spare_partslist[(i * 2) + j * 5 + k] + ".txt");
                            writer.AutoFlush = true;
                            writer.WriteLine("10");
                            writer.Close();
                        }
                    }
                }
            }
        }
        internal static List<Marka> GetBrands() 
        {
            List<Marka> brands = new List<Marka>();
            StreamReader Brandreader = new StreamReader("Brands/Brands_list.txt");
            int i_limit = Convert.ToInt32(Brandreader.ReadLine());
            for(int i = 0; i < i_limit; i++) 
            {
                Marka marka = new Marka(Brandreader.ReadLine());
                StreamReader Modelreader = new StreamReader("Brands/"+marka.isim+ "/model_list.txt");
                int j_limit = Convert.ToInt32(Modelreader.ReadLine());
                for(int j = 0; j < j_limit; j++) 
                {
                    Model model = new Model(Modelreader.ReadLine());
                    StreamReader Donanimreader = new StreamReader("Brands/" + marka.isim + "/" + model.isim + "/donanim_list.txt");
                    int k_limit = Convert.ToInt32(Donanimreader.ReadLine());
                    for (int k = 0; k < k_limit; k++) 
                    {
                        Donanim donanim = new Donanim(Donanimreader.ReadLine());
                        StreamReader Partreader = new StreamReader("Brands/" + marka.isim + "/" + model.isim + "/" + donanim.isim+ "/spare_parts_list.txt");
                        int l_limit = Convert.ToInt32(Partreader.ReadLine());
                        for(int l=0;l<l_limit; l++) 
                        {
                            Yedek_parca yedek_Parca = new Yedek_parca(Partreader.ReadLine());
                            StreamReader Ineventoryreader = new StreamReader("Brands/" + marka.isim + "/" + model.isim + "/" + donanim.isim + "/"+yedek_Parca.isim+".txt");
                            yedek_Parca.inventory = Convert.ToInt32(Ineventoryreader.ReadLine());
                            Ineventoryreader.Close();
                            donanim.yedek_parcalar.Add(yedek_Parca);
                        }
                        Partreader.Close();
                        model.donanimlar.Add(donanim);
                    }
                    Donanimreader.Close();
                    marka.modeller.Add(model);
                }
                Modelreader.Close();
                brands.Add(marka);
            }
            Brandreader.Close();
            return brands;
        }
        internal static void AddBrand(Marka marka) 
        {
            if(Directory.Exists("Brands/"+ marka.isim)) {} 
            else 
            {
                StreamReader reader = new StreamReader("Brands/Brands_list.txt");
                List<string> strings = new List<string>();
                int n = Convert.ToInt32(reader.ReadLine());
                for(int i = 0; i < n; i++) { strings.Add(reader.ReadLine());}
                reader.Close();
                StreamWriter writer = new StreamWriter("Brands/Brands_list.txt");
                writer.AutoFlush = true;
                writer.WriteLine(Convert.ToString(n+1));
                for(int i = 0;i < n;i++) { writer.WriteLine(strings[i]);}
                writer.WriteLine(marka.isim);
                writer.Close();
                Directory.CreateDirectory("Brands/" + marka.isim);
            }
            if (marka.modeller.Count > 0) 
            {
                for (int i = 0; i < marka.modeller.Count; i++)
                {
                    Model model = marka.modeller[i];
                    if (Directory.Exists("Brands/" + marka.isim + "/" + model.isim)) { }
                    else 
                    {
                        StreamWriter writer = new StreamWriter("Brands/" + marka.isim + "/model_list.txt",false);
                        writer.AutoFlush = true;
                        writer.WriteLine(Convert.ToString(marka.modeller.Count));
                        for(int j =0;j< marka.modeller.Count; j++) { writer.WriteLine(marka.modeller[j].isim); }
                        writer.Close();
                        Directory.CreateDirectory("Brands/" + marka.isim + "/" + model.isim);
                    }
                    if (model.donanimlar.Count > 0) 
                    {
                        for(int j = 0; j < model.donanimlar.Count; j++) 
                        {
                            Donanim donanim = model.donanimlar[j];
                            if(Directory.Exists("Brands/" + marka.isim + "/" + model.isim + "/" + donanim.isim)) { }
                            else 
                            {
                                StreamWriter writer = new StreamWriter("Brands/" + marka.isim + "/" + model.isim + "/donanim_list.txt",false);
                                writer.AutoFlush = true;
                                writer.WriteLine(Convert.ToString(model.donanimlar.Count));
                                for (int k = 0; k < model.donanimlar.Count; k++) { writer.WriteLine(model.donanimlar[k].isim); }
                                writer.Close();
                                Directory.CreateDirectory("Brands/" + marka.isim + "/" + model.isim);
                            }
                            if(donanim.yedek_parcalar.Count > 0) 
                            {
                                StreamWriter writer = new StreamWriter("Brands/" + marka.isim + "/" + model.isim + "/" + donanim.isim + "/spare_parts_list",false);
                                writer.AutoFlush = true;
                                writer.WriteLine(Convert.ToString(donanim.yedek_parcalar.Count));
                                for (int k = 0; k < donanim.yedek_parcalar.Count; k++) { writer.WriteLine(donanim.yedek_parcalar[k].isim); }
                                writer.Close();
                                for (int k = 0; k < donanim.yedek_parcalar.Count; k++) 
                                {
                                    Yedek_parca yedek_Parca = donanim.yedek_parcalar[k];
                                    writer = new StreamWriter("Brands/" + marka.isim + "/" + model.isim + "/" + donanim.isim + "/" + yedek_Parca.isim, false);
                                    writer.AutoFlush = true;
                                    writer.WriteLine(Convert.ToString(yedek_Parca.inventory));
                                    writer.Close();
                                }
                            }
                        }
                    }
                }
            }
        }
        internal static List<Invoice> GetInvoices() 
        {
            List<Invoice> list = new List<Invoice>();
            if (Directory.Exists("Invoices")) 
            {
                StreamReader reader = new StreamReader("Invoices/invoice_list.txt");
                int n= Convert.ToInt32(reader.ReadLine());
                for(int i = 0; i < n; i++) 
                {
                    Invoice invoice = new Invoice();
                    StreamReader new_reader = new StreamReader("Invoices/" + reader.ReadLine() + ".txt");
                    invoice.part_name = new_reader.ReadLine();
                    invoice.part_path = new_reader.ReadLine();
                    invoice.customer = new_reader.ReadLine();
                    invoice.amount = Convert.ToInt32(new_reader.ReadLine());
                    invoice.status = new_reader.ReadLine();
                    invoice.date = new_reader.ReadLine();
                    new_reader.Close();
                    list.Add(invoice);
                }
                reader.Close();
            }
            else 
            {
                Directory.CreateDirectory("Invoices");
                File.Create("Invoices/invoice_list.txt").Close();
                StreamWriter writer = new StreamWriter("Invoices/invoice_list.txt");
                writer.AutoFlush = true;
                writer.WriteLine("0");
                writer.Close();
            }
            return list;
        }
        internal static void AddInvoice(Invoice invoice) 
        {
            StreamReader reader = new StreamReader("Invoices/invoice_list.txt");
            List<string> strings = new List<string>();
            int n = Convert.ToInt32(reader.ReadLine());
            for (int i = 0; i < n; i++)
            {
                strings.Add(reader.ReadLine());
            }
            reader.Close();

            StreamWriter writer = new StreamWriter("Invoices/invoice_list.txt");
            writer.AutoFlush = true;
            writer.WriteLine(Convert.ToString(n + 1));
            for (int i = 0; i < n; i++)
            {
                writer.WriteLine(strings[i]);
            }
            string name = invoice.part_name + invoice.date;
            name.Replace(' ', '_');
            writer.WriteLine(name);
            writer.Close();

            File.Create("Invoices/" + name + ".txt").Close();
            writer = new StreamWriter("Invoices/" + name + ".txt");
            writer.AutoFlush = true;
            writer.WriteLine(invoice.part_name);
            writer.WriteLine(invoice.part_path);
            writer.WriteLine(invoice.customer);
            writer.WriteLine(Convert.ToString(invoice.amount));
            writer.WriteLine(invoice.status);
            writer.WriteLine(invoice.date);
            writer.Close();
        }
        internal static void HandleInvoice(Invoice invoice,string status) 
        {
            if(status == "Satın alma olumlu") 
            {
                StreamReader reader1 = new StreamReader(invoice.part_path);
                int m = Convert.ToInt32(reader1.ReadLine());
                reader1.Close();
                m -= invoice.amount;
                if (m >= 0) 
                {
                    StreamWriter writer1 = new StreamWriter(invoice.part_path);
                    writer1.AutoFlush = true;
                    writer1.WriteLine(Convert.ToString(m));
                }
                else 
                {
                    MessageBox.Show("Yeterince Envanter olmadığı için sipariş reddedildi!","yeterince envanter yok");
                    status = "Not enough inventory";
                }
            }
            invoice.status = status;
            StreamReader reader = new StreamReader("Invoices/invoice_list.txt");
            List<string> strings = new List<string>();
            int n = Convert.ToInt32(reader.ReadLine());
            for(int i=0; i<n; i++) 
            {
                strings.Add(reader.ReadLine());
            }
            reader.Close();
            StreamWriter writer = new StreamWriter("Invoices/invoice_list.txt");
            writer.AutoFlush = true;
            writer.WriteLine(Convert.ToString(n - 1));
            string name = invoice.part_name + invoice.date;
            strings.Remove(name);
            for(int i=0; i<n-1; i++) 
            {
                writer.WriteLine(strings[i]);
            }
            writer.Close();
            writer = new StreamWriter("Invoices/" + name + ".txt");
            writer.AutoFlush = true;
            writer.WriteLine(invoice.part_name);
            writer.WriteLine(invoice.part_path);
            writer.WriteLine(invoice.customer);
            writer.WriteLine(Convert.ToString(invoice.amount));
            writer.WriteLine(invoice.status);
            writer.WriteLine(invoice.date);
            writer.Close();
        }
    }
}
