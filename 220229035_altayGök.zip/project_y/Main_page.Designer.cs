﻿//220229035 altay_gök
namespace project_y
{
    partial class Main_page
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            nickname_input = new TextBox();
            password_input = new TextBox();
            label2 = new Label();
            Login_button = new Button();
            label3 = new Label();
            loginPanel = new Panel();
            RegisterPanel = new Panel();
            RAType_input = new ComboBox();
            label10 = new Label();
            REmail_input = new TextBox();
            label9 = new Label();
            RNumber_input = new TextBox();
            label8 = new Label();
            RName_input = new TextBox();
            label7 = new Label();
            label4 = new Label();
            RPassword_input = new TextBox();
            Register_button = new Button();
            label5 = new Label();
            label6 = new Label();
            RNickname_input = new TextBox();
            musteri_panel = new Panel();
            Logout_button = new Button();
            Delete_musteri_account_button = new Button();
            label16 = new Label();
            Musteri_donanim_selection = new ComboBox();
            Musteri_Shopping_list = new ComboBox();
            Musteri_spare_part_selection = new ComboBox();
            Musteri_model_selection = new ComboBox();
            Musteri_brand_selection = new ComboBox();
            Musteri_add_to_cart = new Button();
            label15 = new Label();
            Musteri_amount = new NumericUpDown();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            satici_panel = new Panel();
            Yonetici_panel = new Panel();
            label26 = new Label();
            comboBox2 = new ComboBox();
            button2 = new Button();
            label25 = new Label();
            label24 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            label23 = new Label();
            comboBox1 = new ComboBox();
            Satici_delete_user = new Button();
            Satici_Logut = new Button();
            Invoice_decline = new Button();
            Invoice_confirm = new Button();
            Satici_invoices = new ComboBox();
            label17 = new Label();
            Delete_brand = new Button();
            Satici_donanim_selection = new ComboBox();
            Satici_spare_parts_selection = new ComboBox();
            Satici_Model_selection = new ComboBox();
            Satici_Brand_selection = new ComboBox();
            label18 = new Label();
            ineventory = new NumericUpDown();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            button3 = new Button();
            loginPanel.SuspendLayout();
            RegisterPanel.SuspendLayout();
            musteri_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Musteri_amount).BeginInit();
            satici_panel.SuspendLayout();
            Yonetici_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ineventory).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(357, 91);
            label1.Name = "label1";
            label1.Size = new Size(96, 20);
            label1.TabIndex = 0;
            label1.Text = "Kullanıcı Adı";
            // 
            // nickname_input
            // 
            nickname_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            nickname_input.Cursor = Cursors.IBeam;
            nickname_input.Location = new Point(343, 121);
            nickname_input.Name = "nickname_input";
            nickname_input.PlaceholderText = "Kullanıcı adı";
            nickname_input.Size = new Size(125, 27);
            nickname_input.TabIndex = 2;
            nickname_input.TextAlign = HorizontalAlignment.Center;
            // 
            // password_input
            // 
            password_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            password_input.Cursor = Cursors.IBeam;
            password_input.Location = new Point(343, 191);
            password_input.Name = "password_input";
            password_input.PlaceholderText = "Şifre";
            password_input.Size = new Size(125, 27);
            password_input.TabIndex = 3;
            password_input.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(385, 168);
            label2.Name = "label2";
            label2.Size = new Size(41, 20);
            label2.TabIndex = 4;
            label2.Text = "Şifre";
            // 
            // Login_button
            // 
            Login_button.Cursor = Cursors.Hand;
            Login_button.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Login_button.Location = new Point(357, 249);
            Login_button.Name = "Login_button";
            Login_button.Size = new Size(94, 29);
            Login_button.TabIndex = 5;
            Login_button.Text = "Giriş";
            Login_button.UseVisualStyleBackColor = true;
            Login_button.Click += Login_button_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Cursor = Cursors.Hand;
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(290, 281);
            label3.Name = "label3";
            label3.Size = new Size(245, 20);
            label3.TabIndex = 6;
            label3.Text = "Hesabın yokmu? Yeni hesap oluştur!";
            label3.Click += label3_Click;
            // 
            // loginPanel
            // 
            loginPanel.Controls.Add(label3);
            loginPanel.Controls.Add(password_input);
            loginPanel.Controls.Add(Login_button);
            loginPanel.Controls.Add(label1);
            loginPanel.Controls.Add(label2);
            loginPanel.Controls.Add(nickname_input);
            loginPanel.Dock = DockStyle.Fill;
            loginPanel.Location = new Point(0, 0);
            loginPanel.Name = "loginPanel";
            loginPanel.Size = new Size(832, 453);
            loginPanel.TabIndex = 7;
            // 
            // RegisterPanel
            // 
            RegisterPanel.Controls.Add(RAType_input);
            RegisterPanel.Controls.Add(label10);
            RegisterPanel.Controls.Add(REmail_input);
            RegisterPanel.Controls.Add(label9);
            RegisterPanel.Controls.Add(RNumber_input);
            RegisterPanel.Controls.Add(label8);
            RegisterPanel.Controls.Add(RName_input);
            RegisterPanel.Controls.Add(label7);
            RegisterPanel.Controls.Add(label4);
            RegisterPanel.Controls.Add(RPassword_input);
            RegisterPanel.Controls.Add(Register_button);
            RegisterPanel.Controls.Add(label5);
            RegisterPanel.Controls.Add(label6);
            RegisterPanel.Controls.Add(RNickname_input);
            RegisterPanel.Dock = DockStyle.Fill;
            RegisterPanel.Location = new Point(0, 0);
            RegisterPanel.Name = "RegisterPanel";
            RegisterPanel.Size = new Size(832, 453);
            RegisterPanel.TabIndex = 8;
            RegisterPanel.Visible = false;
            // 
            // RAType_input
            // 
            RAType_input.DropDownStyle = ComboBoxStyle.DropDownList;
            RAType_input.FormattingEnabled = true;
            RAType_input.Items.AddRange(new object[] { "Müşteri", "Satıcı" });
            RAType_input.Location = new Point(469, 221);
            RAType_input.Name = "RAType_input";
            RAType_input.Size = new Size(180, 28);
            RAType_input.TabIndex = 15;
            RAType_input.SelectedIndexChanged += RAType_input_SelectedIndexChanged;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label10.Location = new Point(511, 198);
            label10.Name = "label10";
            label10.Size = new Size(79, 20);
            label10.TabIndex = 14;
            label10.Text = "Hesap tipi";
            // 
            // REmail_input
            // 
            REmail_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            REmail_input.Cursor = Cursors.IBeam;
            REmail_input.Location = new Point(220, 144);
            REmail_input.Name = "REmail_input";
            REmail_input.PlaceholderText = "xxxx@gmail.com";
            REmail_input.Size = new Size(180, 27);
            REmail_input.TabIndex = 11;
            REmail_input.TextAlign = HorizontalAlignment.Center;
            REmail_input.TextChanged += REmail_input_TextChanged;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label9.Location = new Point(284, 124);
            label9.Name = "label9";
            label9.Size = new Size(47, 20);
            label9.TabIndex = 12;
            label9.Text = "Email";
            // 
            // RNumber_input
            // 
            RNumber_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            RNumber_input.Cursor = Cursors.IBeam;
            RNumber_input.Location = new Point(469, 144);
            RNumber_input.Name = "RNumber_input";
            RNumber_input.PlaceholderText = "xxx-xxx-xxxx";
            RNumber_input.Size = new Size(180, 27);
            RNumber_input.TabIndex = 9;
            RNumber_input.TextAlign = HorizontalAlignment.Center;
            RNumber_input.TextChanged += RNumber_input_TextChanged;
            RNumber_input.KeyPress += RNumber_input_KeyPress;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label8.Location = new Point(517, 121);
            label8.Name = "label8";
            label8.Size = new Size(83, 20);
            label8.TabIndex = 10;
            label8.Text = "Telefon no";
            // 
            // RName_input
            // 
            RName_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            RName_input.Cursor = Cursors.IBeam;
            RName_input.Location = new Point(220, 221);
            RName_input.Name = "RName_input";
            RName_input.PlaceholderText = "İsim-soyisim";
            RName_input.Size = new Size(180, 27);
            RName_input.TabIndex = 7;
            RName_input.TextAlign = HorizontalAlignment.Center;
            RName_input.TextChanged += RName_input_TextChanged;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label7.Location = new Point(262, 198);
            label7.Name = "label7";
            label7.Size = new Size(98, 20);
            label7.TabIndex = 8;
            label7.Text = "İsim-soyisim";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Cursor = Cursors.Hand;
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(314, 372);
            label4.Name = "label4";
            label4.Size = new Size(221, 20);
            label4.TabIndex = 6;
            label4.Text = "Çoktan kaydoldunmu? Giriş yap!";
            label4.Click += label4_Click;
            // 
            // RPassword_input
            // 
            RPassword_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            RPassword_input.Cursor = Cursors.IBeam;
            RPassword_input.Location = new Point(469, 55);
            RPassword_input.Name = "RPassword_input";
            RPassword_input.PlaceholderText = "Şifre";
            RPassword_input.Size = new Size(125, 27);
            RPassword_input.TabIndex = 3;
            RPassword_input.TextAlign = HorizontalAlignment.Center;
            RPassword_input.TextChanged += RPassword_input_TextChanged;
            // 
            // Register_button
            // 
            Register_button.BackColor = Color.Ivory;
            Register_button.Cursor = Cursors.Hand;
            Register_button.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Register_button.Location = new Point(374, 340);
            Register_button.Name = "Register_button";
            Register_button.Size = new Size(94, 29);
            Register_button.TabIndex = 5;
            Register_button.Text = "Kayıt ol";
            Register_button.UseVisualStyleBackColor = false;
            Register_button.Click += Register_button_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(290, 32);
            label5.Name = "label5";
            label5.Size = new Size(96, 20);
            label5.TabIndex = 0;
            label5.Text = "Kullanıcı Adı";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label6.Location = new Point(511, 32);
            label6.Name = "label6";
            label6.Size = new Size(41, 20);
            label6.TabIndex = 4;
            label6.Text = "Şifre";
            // 
            // RNickname_input
            // 
            RNickname_input.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            RNickname_input.Cursor = Cursors.IBeam;
            RNickname_input.Location = new Point(275, 55);
            RNickname_input.Name = "RNickname_input";
            RNickname_input.PlaceholderText = "Kullanıcı adı";
            RNickname_input.Size = new Size(125, 27);
            RNickname_input.TabIndex = 2;
            RNickname_input.TextAlign = HorizontalAlignment.Center;
            RNickname_input.TextChanged += RNickname_input_TextChanged;
            // 
            // musteri_panel
            // 
            musteri_panel.Controls.Add(Logout_button);
            musteri_panel.Controls.Add(Delete_musteri_account_button);
            musteri_panel.Controls.Add(label16);
            musteri_panel.Controls.Add(Musteri_donanim_selection);
            musteri_panel.Controls.Add(Musteri_Shopping_list);
            musteri_panel.Controls.Add(Musteri_spare_part_selection);
            musteri_panel.Controls.Add(Musteri_model_selection);
            musteri_panel.Controls.Add(Musteri_brand_selection);
            musteri_panel.Controls.Add(Musteri_add_to_cart);
            musteri_panel.Controls.Add(label15);
            musteri_panel.Controls.Add(Musteri_amount);
            musteri_panel.Controls.Add(label14);
            musteri_panel.Controls.Add(label13);
            musteri_panel.Controls.Add(label12);
            musteri_panel.Controls.Add(label11);
            musteri_panel.Dock = DockStyle.Fill;
            musteri_panel.Location = new Point(0, 0);
            musteri_panel.Name = "musteri_panel";
            musteri_panel.Size = new Size(832, 453);
            musteri_panel.TabIndex = 16;
            musteri_panel.VisibleChanged += musteri_panel_VisibleChanged;
            // 
            // Logout_button
            // 
            Logout_button.BackColor = Color.Ivory;
            Logout_button.Cursor = Cursors.Hand;
            Logout_button.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Logout_button.Location = new Point(632, 375);
            Logout_button.Name = "Logout_button";
            Logout_button.Size = new Size(150, 29);
            Logout_button.TabIndex = 19;
            Logout_button.Text = "Çıkış yap";
            Logout_button.UseVisualStyleBackColor = false;
            Logout_button.Click += Logout_button_Click;
            // 
            // Delete_musteri_account_button
            // 
            Delete_musteri_account_button.BackColor = Color.Ivory;
            Delete_musteri_account_button.Cursor = Cursors.Hand;
            Delete_musteri_account_button.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Delete_musteri_account_button.Location = new Point(632, 340);
            Delete_musteri_account_button.Name = "Delete_musteri_account_button";
            Delete_musteri_account_button.Size = new Size(150, 29);
            Delete_musteri_account_button.TabIndex = 18;
            Delete_musteri_account_button.Text = "Hesabı sil";
            Delete_musteri_account_button.UseVisualStyleBackColor = false;
            Delete_musteri_account_button.Click += Delete_musteri_account_button_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = Color.Black;
            label16.Location = new Point(50, 147);
            label16.Name = "label16";
            label16.Size = new Size(87, 20);
            label16.TabIndex = 17;
            label16.Text = "Siparişlerim";
            // 
            // Musteri_donanim_selection
            // 
            Musteri_donanim_selection.DropDownStyle = ComboBoxStyle.DropDownList;
            Musteri_donanim_selection.FormattingEnabled = true;
            Musteri_donanim_selection.Location = new Point(430, 55);
            Musteri_donanim_selection.Name = "Musteri_donanim_selection";
            Musteri_donanim_selection.Size = new Size(151, 28);
            Musteri_donanim_selection.TabIndex = 16;
            Musteri_donanim_selection.SelectedIndexChanged += Musteri_donanim_selection_SelectedIndexChanged;
            // 
            // Musteri_Shopping_list
            // 
            Musteri_Shopping_list.DropDownStyle = ComboBoxStyle.DropDownList;
            Musteri_Shopping_list.FormattingEnabled = true;
            Musteri_Shopping_list.Location = new Point(50, 169);
            Musteri_Shopping_list.Name = "Musteri_Shopping_list";
            Musteri_Shopping_list.Size = new Size(345, 28);
            Musteri_Shopping_list.TabIndex = 15;
            // 
            // Musteri_spare_part_selection
            // 
            Musteri_spare_part_selection.DropDownStyle = ComboBoxStyle.DropDownList;
            Musteri_spare_part_selection.FormattingEnabled = true;
            Musteri_spare_part_selection.Location = new Point(631, 55);
            Musteri_spare_part_selection.Name = "Musteri_spare_part_selection";
            Musteri_spare_part_selection.Size = new Size(151, 28);
            Musteri_spare_part_selection.TabIndex = 14;
            Musteri_spare_part_selection.SelectedIndexChanged += Musteri_spare_part_selection_SelectedIndexChanged;
            // 
            // Musteri_model_selection
            // 
            Musteri_model_selection.DropDownStyle = ComboBoxStyle.DropDownList;
            Musteri_model_selection.FormattingEnabled = true;
            Musteri_model_selection.Location = new Point(244, 55);
            Musteri_model_selection.Name = "Musteri_model_selection";
            Musteri_model_selection.Size = new Size(151, 28);
            Musteri_model_selection.TabIndex = 13;
            Musteri_model_selection.SelectedIndexChanged += Musteri_model_selection_SelectedIndexChanged;
            // 
            // Musteri_brand_selection
            // 
            Musteri_brand_selection.DropDownStyle = ComboBoxStyle.DropDownList;
            Musteri_brand_selection.FormattingEnabled = true;
            Musteri_brand_selection.Location = new Point(50, 55);
            Musteri_brand_selection.Name = "Musteri_brand_selection";
            Musteri_brand_selection.Size = new Size(151, 28);
            Musteri_brand_selection.TabIndex = 12;
            Musteri_brand_selection.SelectedIndexChanged += Musteri_brand_selection_SelectedIndexChanged;
            // 
            // Musteri_add_to_cart
            // 
            Musteri_add_to_cart.BackColor = Color.Ivory;
            Musteri_add_to_cart.Cursor = Cursors.Hand;
            Musteri_add_to_cart.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Musteri_add_to_cart.Location = new Point(632, 168);
            Musteri_add_to_cart.Name = "Musteri_add_to_cart";
            Musteri_add_to_cart.Size = new Size(150, 29);
            Musteri_add_to_cart.TabIndex = 10;
            Musteri_add_to_cart.Text = "Sipariş et";
            Musteri_add_to_cart.UseVisualStyleBackColor = false;
            Musteri_add_to_cart.Click += Musteri_add_to_cart_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.Black;
            label15.Location = new Point(632, 98);
            label15.Name = "label15";
            label15.Size = new Size(102, 20);
            label15.TabIndex = 9;
            label15.Text = "İstenen miktar";
            label15.Visible = false;
            // 
            // Musteri_amount
            // 
            Musteri_amount.Location = new Point(632, 121);
            Musteri_amount.Name = "Musteri_amount";
            Musteri_amount.Size = new Size(150, 27);
            Musteri_amount.TabIndex = 8;
            Musteri_amount.Visible = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.Black;
            label14.Location = new Point(244, 32);
            label14.Name = "label14";
            label14.Size = new Size(52, 20);
            label14.TabIndex = 7;
            label14.Text = "Model";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = Color.Black;
            label13.Location = new Point(430, 32);
            label13.Name = "label13";
            label13.Size = new Size(70, 20);
            label13.TabIndex = 6;
            label13.Text = "Donanım";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.Black;
            label12.Location = new Point(632, 32);
            label12.Name = "label12";
            label12.Size = new Size(89, 20);
            label12.TabIndex = 5;
            label12.Text = "Yedek parça";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.Black;
            label11.Location = new Point(50, 32);
            label11.Name = "label11";
            label11.Size = new Size(50, 20);
            label11.TabIndex = 4;
            label11.Text = "Marka";
            // 
            // satici_panel
            // 
            satici_panel.Controls.Add(Yonetici_panel);
            satici_panel.Controls.Add(Satici_delete_user);
            satici_panel.Controls.Add(Satici_Logut);
            satici_panel.Controls.Add(Invoice_decline);
            satici_panel.Controls.Add(Invoice_confirm);
            satici_panel.Controls.Add(Satici_invoices);
            satici_panel.Controls.Add(label17);
            satici_panel.Controls.Add(Delete_brand);
            satici_panel.Controls.Add(Satici_donanim_selection);
            satici_panel.Controls.Add(Satici_spare_parts_selection);
            satici_panel.Controls.Add(Satici_Model_selection);
            satici_panel.Controls.Add(Satici_Brand_selection);
            satici_panel.Controls.Add(label18);
            satici_panel.Controls.Add(ineventory);
            satici_panel.Controls.Add(label19);
            satici_panel.Controls.Add(label20);
            satici_panel.Controls.Add(label21);
            satici_panel.Controls.Add(label22);
            satici_panel.Dock = DockStyle.Fill;
            satici_panel.Location = new Point(0, 0);
            satici_panel.Name = "satici_panel";
            satici_panel.Size = new Size(832, 453);
            satici_panel.TabIndex = 20;
            satici_panel.VisibleChanged += satici_panel_VisibleChanged;
            // 
            // Yonetici_panel
            // 
            Yonetici_panel.Controls.Add(button3);
            Yonetici_panel.Controls.Add(label26);
            Yonetici_panel.Controls.Add(comboBox2);
            Yonetici_panel.Controls.Add(button2);
            Yonetici_panel.Controls.Add(label25);
            Yonetici_panel.Controls.Add(label24);
            Yonetici_panel.Controls.Add(textBox1);
            Yonetici_panel.Controls.Add(button1);
            Yonetici_panel.Controls.Add(label23);
            Yonetici_panel.Controls.Add(comboBox1);
            Yonetici_panel.Dock = DockStyle.Fill;
            Yonetici_panel.Location = new Point(0, 0);
            Yonetici_panel.Name = "Yonetici_panel";
            Yonetici_panel.Size = new Size(832, 453);
            Yonetici_panel.TabIndex = 36;
            Yonetici_panel.VisibleChanged += Yonetici_panel_VisibleChanged;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(460, 141);
            label26.Name = "label26";
            label26.Size = new Size(252, 20);
            label26.TabIndex = 8;
            label26.Text = "Silmek istedğiniz şeyin türünü seçiniz";
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "marka", "model", "donanım", "yedek parça" });
            comboBox2.Location = new Point(461, 165);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(251, 28);
            comboBox2.TabIndex = 7;
            // 
            // button2
            // 
            button2.Location = new Point(718, 164);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 6;
            button2.Text = "Sil";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(50, 194);
            label25.Name = "label25";
            label25.Size = new Size(281, 20);
            label25.TabIndex = 5;
            label25.Text = "Örn: marka/model/donanım/yedek parça";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(50, 142);
            label24.Name = "label24";
            label24.Size = new Size(206, 20);
            label24.TabIndex = 4;
            label24.Text = "Silmek istediğiniz aracı giriniz";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(50, 165);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(403, 27);
            textBox1.TabIndex = 3;
            // 
            // button1
            // 
            button1.Location = new Point(220, 53);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "Sil";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(55, 31);
            label23.Name = "label23";
            label23.Size = new Size(82, 20);
            label23.TabIndex = 1;
            label23.Text = "Kullanıcılar";
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(50, 55);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 0;
            // 
            // Satici_delete_user
            // 
            Satici_delete_user.BackColor = Color.Ivory;
            Satici_delete_user.Cursor = Cursors.Hand;
            Satici_delete_user.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Satici_delete_user.Location = new Point(623, 340);
            Satici_delete_user.Name = "Satici_delete_user";
            Satici_delete_user.Size = new Size(150, 29);
            Satici_delete_user.TabIndex = 35;
            Satici_delete_user.Text = "Hesabı sil";
            Satici_delete_user.UseVisualStyleBackColor = false;
            Satici_delete_user.Click += Satici_delete_user_Click;
            // 
            // Satici_Logut
            // 
            Satici_Logut.BackColor = Color.Ivory;
            Satici_Logut.Cursor = Cursors.Hand;
            Satici_Logut.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Satici_Logut.Location = new Point(623, 375);
            Satici_Logut.Name = "Satici_Logut";
            Satici_Logut.Size = new Size(150, 29);
            Satici_Logut.TabIndex = 34;
            Satici_Logut.Text = "Çıkış yap";
            Satici_Logut.UseVisualStyleBackColor = false;
            Satici_Logut.Click += Logout_button_Click;
            // 
            // Invoice_decline
            // 
            Invoice_decline.BackColor = Color.Ivory;
            Invoice_decline.Cursor = Cursors.Hand;
            Invoice_decline.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Invoice_decline.Location = new Point(235, 190);
            Invoice_decline.Name = "Invoice_decline";
            Invoice_decline.Size = new Size(150, 29);
            Invoice_decline.TabIndex = 33;
            Invoice_decline.Text = "Reddet";
            Invoice_decline.UseVisualStyleBackColor = false;
            Invoice_decline.Click += Invoice_decline_Click;
            // 
            // Invoice_confirm
            // 
            Invoice_confirm.BackColor = Color.Ivory;
            Invoice_confirm.Cursor = Cursors.Hand;
            Invoice_confirm.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Invoice_confirm.Location = new Point(41, 189);
            Invoice_confirm.Name = "Invoice_confirm";
            Invoice_confirm.Size = new Size(150, 29);
            Invoice_confirm.TabIndex = 32;
            Invoice_confirm.Text = "Onayla";
            Invoice_confirm.UseVisualStyleBackColor = false;
            Invoice_confirm.Click += Invoice_confirm_Click;
            // 
            // Satici_invoices
            // 
            Satici_invoices.FormattingEnabled = true;
            Satici_invoices.Location = new Point(41, 144);
            Satici_invoices.Name = "Satici_invoices";
            Satici_invoices.Size = new Size(345, 28);
            Satici_invoices.TabIndex = 31;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = Color.Black;
            label17.Location = new Point(41, 120);
            label17.Name = "label17";
            label17.Size = new Size(70, 20);
            label17.TabIndex = 30;
            label17.Text = "Siparişler";
            // 
            // Delete_brand
            // 
            Delete_brand.BackColor = Color.Ivory;
            Delete_brand.Cursor = Cursors.Hand;
            Delete_brand.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Delete_brand.Location = new Point(623, 169);
            Delete_brand.Name = "Delete_brand";
            Delete_brand.Size = new Size(150, 29);
            Delete_brand.TabIndex = 28;
            Delete_brand.Text = "Sistemden Sil";
            Delete_brand.UseVisualStyleBackColor = false;
            Delete_brand.Click += Delete_brand_Click;
            // 
            // Satici_donanim_selection
            // 
            Satici_donanim_selection.FormattingEnabled = true;
            Satici_donanim_selection.Location = new Point(421, 54);
            Satici_donanim_selection.Name = "Satici_donanim_selection";
            Satici_donanim_selection.Size = new Size(151, 28);
            Satici_donanim_selection.TabIndex = 27;
            Satici_donanim_selection.KeyPress += enter_press;
            Satici_donanim_selection.Leave += Satici_donanim_selection_Leave;
            // 
            // Satici_spare_parts_selection
            // 
            Satici_spare_parts_selection.FormattingEnabled = true;
            Satici_spare_parts_selection.Location = new Point(622, 54);
            Satici_spare_parts_selection.Name = "Satici_spare_parts_selection";
            Satici_spare_parts_selection.Size = new Size(151, 28);
            Satici_spare_parts_selection.TabIndex = 26;
            Satici_spare_parts_selection.KeyPress += enter_press;
            Satici_spare_parts_selection.Leave += Satici_spare_parts_selection_Leave;
            // 
            // Satici_Model_selection
            // 
            Satici_Model_selection.FormattingEnabled = true;
            Satici_Model_selection.Location = new Point(235, 54);
            Satici_Model_selection.Name = "Satici_Model_selection";
            Satici_Model_selection.Size = new Size(151, 28);
            Satici_Model_selection.TabIndex = 25;
            Satici_Model_selection.KeyPress += enter_press;
            Satici_Model_selection.Leave += Satici_Model_selection_Leave;
            // 
            // Satici_Brand_selection
            // 
            Satici_Brand_selection.FormattingEnabled = true;
            Satici_Brand_selection.Location = new Point(41, 54);
            Satici_Brand_selection.Name = "Satici_Brand_selection";
            Satici_Brand_selection.Size = new Size(151, 28);
            Satici_Brand_selection.TabIndex = 24;
            Satici_Brand_selection.KeyPress += enter_press;
            Satici_Brand_selection.Leave += Satici_Brand_selection_Leave;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.ForeColor = Color.Black;
            label18.Location = new Point(623, 97);
            label18.Name = "label18";
            label18.Size = new Size(66, 20);
            label18.TabIndex = 23;
            label18.Text = "Envanter";
            label18.Visible = false;
            // 
            // ineventory
            // 
            ineventory.Location = new Point(623, 120);
            ineventory.Name = "ineventory";
            ineventory.Size = new Size(150, 27);
            ineventory.TabIndex = 22;
            ineventory.Visible = false;
            ineventory.KeyPress += enter_press;
            ineventory.Leave += ineventory_Leave;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.ForeColor = Color.Black;
            label19.Location = new Point(235, 31);
            label19.Name = "label19";
            label19.Size = new Size(52, 20);
            label19.TabIndex = 21;
            label19.Text = "Model";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.ForeColor = Color.Black;
            label20.Location = new Point(421, 31);
            label20.Name = "label20";
            label20.Size = new Size(70, 20);
            label20.TabIndex = 20;
            label20.Text = "Donanım";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.ForeColor = Color.Black;
            label21.Location = new Point(623, 31);
            label21.Name = "label21";
            label21.Size = new Size(89, 20);
            label21.TabIndex = 19;
            label21.Text = "Yedek parça";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.ForeColor = Color.Black;
            label22.Location = new Point(41, 31);
            label22.Name = "label22";
            label22.Size = new Size(50, 20);
            label22.TabIndex = 18;
            label22.Text = "Marka";
            // 
            // button3
            // 
            button3.Location = new Point(688, 363);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 9;
            button3.Text = "çıkış yap";
            button3.UseVisualStyleBackColor = true;
            button3.Click += Logout_button_Click;
            // 
            // Main_page
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGreen;
            ClientSize = new Size(832, 453);
            Controls.Add(Yonetici_panel);
            Controls.Add(satici_panel);
            Controls.Add(musteri_panel);
            Controls.Add(RegisterPanel);
            Controls.Add(loginPanel);
            ForeColor = SystemColors.Desktop;
            Name = "Main_page";
            Text = "Pro lab 3";
            MouseClick += Form1_MouseClick;
            loginPanel.ResumeLayout(false);
            loginPanel.PerformLayout();
            RegisterPanel.ResumeLayout(false);
            RegisterPanel.PerformLayout();
            musteri_panel.ResumeLayout(false);
            musteri_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Musteri_amount).EndInit();
            satici_panel.ResumeLayout(false);
            satici_panel.PerformLayout();
            Yonetici_panel.ResumeLayout(false);
            Yonetici_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ineventory).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox nickname_input;
        private TextBox password_input;
        private Label label2;
        private Button Login_button;
        private Label label3;
        private Panel loginPanel;
        private Panel RegisterPanel;
        private Label label4;
        private TextBox RPassword_input;
        private Button Register_button;
        private Label label5;
        private Label label6;
        private TextBox RNickname_input;
        private TextBox RNumber_input;
        private Label label8;
        private TextBox RName_input;
        private Label label7;
        private TextBox REmail_input;
        private Label label9;
        private Label label10;
        private ComboBox RAType_input;
        private Panel musteri_panel;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label15;
        private NumericUpDown Musteri_amount;
        private Button Musteri_add_to_cart;
        private ComboBox Musteri_brand_selection;
        private ComboBox Musteri_donanim_selection;
        private ComboBox Musteri_Shopping_list;
        private ComboBox Musteri_spare_part_selection;
        private ComboBox Musteri_model_selection;
        private Label label16;
        private Button Logout_button;
        private Button Delete_musteri_account_button;
        private Panel satici_panel;
        private ComboBox Satici_donanim_selection;
        private ComboBox Satici_spare_parts_selection;
        private ComboBox Satici_Model_selection;
        private ComboBox Satici_Brand_selection;
        private Label label18;
        private NumericUpDown ineventory;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Button Delete_brand;
        private Label label17;
        private ComboBox Satici_invoices;
        private Button Invoice_decline;
        private Button Invoice_confirm;
        private Button Satici_delete_user;
        private Button Satici_Logut;
        private Panel Yonetici_panel;
        private Label label23;
        private ComboBox comboBox1;
        private Button button1;
        private Label label25;
        private Label label24;
        private TextBox textBox1;
        private Button button2;
        private Label label26;
        private ComboBox comboBox2;
        private Button button3;
    }
}
