//220229035 altay_g�k
namespace project_y
{
    public partial class Main_page : Form
    {
        internal List<string> users;
        internal List<Marka> Brands;
        internal List<Invoice> Invoices;
        internal Kullan�ci CUser = new Kullan�ci("", "", "", "", "");
        List<bool> register_is_valid = new List<bool>(6);

        public Main_page()
        {
            Setup_wizard.UserInitializer();
            users = Setup_wizard.GetUsers();
            Setup_wizard.BrandInitializer();
            Brands = Setup_wizard.GetBrands();
            Invoices = Setup_wizard.GetInvoices();
            InitializeComponent();
            InitializePanels();
            for (int i = 0; i < 6; i++) { register_is_valid.Add(false); }
        }
        void InitializePanels()
        {
            Yonetici_panel.Visible = false;
            satici_panel.Visible = false;
            musteri_panel.Visible = false;
            RegisterPanel.Visible = false;
            loginPanel.Visible = true;
        }
        void InitializeSelection<T>(ComboBox comboBox, List<T> list)
        {
            comboBox.Items.Clear();
            comboBox.SelectedIndex = -1;
            for (int i = 0; i < list.Count(); i++)
            {
                comboBox.Items.Add(list[i]);
            }
        }
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                BackColor = Color.Red;
            else if (e.Button == MouseButtons.Left)
                BackColor = Color.Aqua;
        }

        private void Login_button_Click(object sender, EventArgs e)
        {
            CUser.takma_isim = nickname_input.Text;
            CUser.sifre = password_input.Text;
            if (users.Contains(CUser.takma_isim))
            {
                StreamReader reader = new StreamReader("Users/" + CUser.takma_isim + ".txt");
                if (CUser.sifre == reader.ReadLine())
                {
                    CUser.id = reader.ReadLine();
                    CUser.isim = reader.ReadLine();
                    CUser.email = reader.ReadLine();
                    CUser.telefon_no = reader.ReadLine();
                    reader.Close();
                    switch (CUser.id[0])
                    {
                        case '1':
                            musteri_panel.Visible = true;
                            break;
                        case '2':
                            satici_panel.Visible = true;
                            break;
                            
                        case '3':
                            Yonetici_panel.Visible = true;
                            break;
                    }
                    loginPanel.Visible = false;
                }
                else
                    MessageBox.Show("Yanl�� Kullanc� ad�/�ifre !", "Giri� ba�ar�s�z!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
                MessageBox.Show("Yanl�� Kullanc� ad�/�ifre !", "Giri� ba�ar�s�z!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void label3_Click(object sender, EventArgs e)
        {
            loginPanel.Visible = false;
            RegisterPanel.Visible = true;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            loginPanel.Visible = true;
            RegisterPanel.Visible = false;
        }

        private void Register_button_Click(object sender, EventArgs e)
        {
            if (!register_is_valid.Contains(false))
            {
                if (RAType_input.SelectedIndex == 0)
                {
                    CUser = new Musteri(RNickname_input.Text, RName_input.Text, REmail_input.Text, RPassword_input.Text, RNumber_input.Text);
                    musteri_panel.Visible = true;
                }
                else
                {
                    CUser = new Satici(RNickname_input.Text, RName_input.Text, REmail_input.Text, RPassword_input.Text, RNumber_input.Text);
                    satici_panel.Visible = true;
                }
                Setup_wizard.Save_new_user(CUser, users);
                RegisterPanel.Visible = false;
            }
            else
            {
                MessageBox.Show("l�tfen t�m alanlar� kabul edilen bi�imde doldurun", "kay�t ba�ar�s�z!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void RNickname_input_TextChanged(object sender, EventArgs e)
        {
            register_is_valid[0] = false;
            if (RNickname_input.Text.Length < 5)
            {
                label5.ForeColor = Color.Red;
                label5.Text = "fazla k�sa!";
            }
            else if (RNickname_input.Text.Length > 20)
            {
                label5.ForeColor = Color.Red;
                label5.Text = "fazla uzun!";
            }
            else
            {
                if (char.IsLetter(RNickname_input.Text[0]))
                {
                    bool is_valid = true;
                    for (int i = 1; i < RNickname_input.Text.Length; i++)
                    {
                        if (!char.IsLetterOrDigit(RNickname_input.Text[i]))
                        {
                            is_valid = false;
                            break;
                        }
                    }
                    if (is_valid)
                    {
                        if (!users.Contains(RNickname_input.Text))
                        {
                            register_is_valid[0] = true;
                            label5.ForeColor = Color.Black;
                            label5.Text = "Kullan�c� Ad�";
                        }
                        else
                        {
                            label5.ForeColor = Color.Red;
                            label5.Text = "bu kullan�c� ad� al�nm��!";
                        }
                    }
                    else
                    {
                        label5.ForeColor = Color.Red;
                        label5.Text = "sadice say� yada harf i�ermerli!";
                    }
                }
                else
                {
                    label5.ForeColor = Color.Red;
                    label5.Text = "ilk karakter harf olmal�d�r!";
                }
            }
        }

        private void RPassword_input_TextChanged(object sender, EventArgs e)
        {
            register_is_valid[1] = false;
            if (RPassword_input.Text.Length < 8)
            {
                label6.ForeColor = Color.Red;
                label6.Text = "fazla k�sa!";
            }
            else if (RPassword_input.Text.Length > 20)
            {
                label6.ForeColor = Color.Red;
                label6.Text = "fazla uzun!";
            }
            else
            {
                if (!RPassword_input.Text.Contains(' '))
                {
                    char c = ' ';
                    bool have_number = false;
                    bool have_upper = false;
                    bool have_lower = false;
                    bool have_special = false;
                    for (int i = 0; i < RPassword_input.Text.Length; i++)
                    {
                        c = RPassword_input.Text[i];
                        if (char.IsDigit(c))
                            have_number = true;
                        else if (char.IsLower(c))
                            have_lower = true;
                        else if (char.IsUpper(c))
                            have_upper = true;
                        else if (!have_special)
                        {
                            switch (c)
                            {
                                case '!':
                                    have_special = true;
                                    break;
                                case '@':
                                    have_special = true;
                                    break;
                                case '#':
                                    have_special = true;
                                    break;
                                case '$':
                                    have_special = true;
                                    break;
                                case '%':
                                    have_special = true;
                                    break;
                                case '&':
                                    have_special = true;
                                    break;
                                case '*':
                                    have_special = true;
                                    break;
                                case '-':
                                    have_special = true;
                                    break;
                                case '+':
                                    have_special = true;
                                    break;
                            }
                        }

                    }
                    if (!have_special)
                    {
                        label6.ForeColor = Color.Red;
                        label6.Text = "!@#$%&*-+ karakterinden birini i�ermeli!";
                    }
                    else if (!have_upper)
                    {
                        label6.ForeColor = Color.Red;
                        label6.Text = "en az bir b�y�k harf i�ermeli!";
                    }
                    else if (!have_number)
                    {
                        label6.ForeColor = Color.Red;
                        label6.Text = "en az bir say� i�ermeli!";
                    }
                    else if (!have_lower)
                    {
                        label6.ForeColor = Color.Red;
                        label6.Text = "en az bir k���k harf i�ermeli!";
                    }
                    else
                    {
                        register_is_valid[1] = true;
                        label6.ForeColor = Color.Black;
                        label6.Text = "�ifre";
                    }
                }
                else
                {
                    label6.ForeColor = Color.Red;
                    label6.Text = "bo�luk i�ermemelidir!";
                }
            }
        }

        private void RName_input_TextChanged(object sender, EventArgs e)
        {
            register_is_valid[4] = false;
            if (!(RName_input.Text.Length > 0)) ;
            else if (char.IsAsciiLetter(RName_input.Text[0]))
            {
                bool is_valid = true;
                for (int i = 1; i < RName_input.Text.Length; i++)
                    if (!char.IsLetterOrDigit(RName_input.Text[i])) { if (RName_input.Text[i] != ' ') { is_valid = false; break; } }
                if (is_valid)
                {
                    register_is_valid[4] = true;
                    label7.ForeColor = Color.Black;
                    label7.Text = "�sim-soyisim";
                }
                else
                {
                    label7.ForeColor = Color.Red;
                    label7.Text = "�zel karakter i�ermemeli!";
                }
            }
            else
            {
                label7.ForeColor = Color.Red;
                label7.Text = "harf ile ba�lmal�!";
            }
        }

        private void REmail_input_TextChanged(object sender, EventArgs e)
        {
            register_is_valid[2] = false;
            if (!(REmail_input.Text.Length > 0)) ;
            else if (char.IsLetterOrDigit(REmail_input.Text[0]))
            {
                if (REmail_input.Text.Contains('@'))
                {
                    register_is_valid[2] = true;
                    label9.ForeColor = Color.Black;
                    label9.Text = "Email";
                }
                else
                {
                    label9.ForeColor = Color.Red;
                    label9.Text = "@ i�ermesi gerekir";
                }
            }
            else
            {
                label9.ForeColor = Color.Red;
                label9.Text = "�zel karakterle ba�layamaz";
            }
        }

        private void RNumber_input_TextChanged(object sender, EventArgs e)
        {
            register_is_valid[3] = false;
            if (!(RNumber_input.Text.Length > 0)) ;
            else if (RNumber_input.Text.Length >= 4 && RNumber_input.Text[3] != '-')
            {
                label8.ForeColor = Color.Red;
                label8.Text = "4. karakter - olmal�!";
            }
            else if (RNumber_input.Text.Length >= 8 && RNumber_input.Text[7] != '-')
            {
                label8.ForeColor = Color.Red;
                label8.Text = "8. karakter - olmal�!";
            }
            else
            {
                bool is_valid = true;
                for (int i = 0; i < RNumber_input.Text.Length; i++)
                {
                    if (i == 3 || i == 7)
                        continue;
                    if (RNumber_input.Text[i] == '-')
                    {
                        is_valid = false;
                        label8.ForeColor = Color.Red;
                        label8.Text = (i + 1) + ".karakter say� olmal�!";
                        break;
                    }
                }
                if (is_valid)
                {
                    if (RNumber_input.Text.Length == 12)
                    {
                        register_is_valid[3] = true;
                        label8.ForeColor = Color.Black;
                        label8.Text = "Telefon no";
                    }
                    else
                    {
                        label8.ForeColor = Color.Red;
                        label8.Text = "fazla k�sa!";
                    }
                }
            }

        }

        private void RNumber_input_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsControl(e.KeyChar) || (RNumber_input.Text.Length < 12 && (char.IsDigit(e.KeyChar) || e.KeyChar == '-'))))
            {
                e.Handled = true;
            }
        }

        private void RAType_input_SelectedIndexChanged(object sender, EventArgs e)
        {
            register_is_valid[5] = false;
            if (RAType_input.SelectedIndex >= 0)
            {
                register_is_valid[5] = true;
            }
        }

        private void musteri_panel_VisibleChanged(object sender, EventArgs e)
        {
            InitializeSelection(Musteri_brand_selection, Brands);
            List<Invoice> my_invoices = Invoices.Where(x => x.customer == CUser.id).ToList();
            InitializeSelection(Musteri_Shopping_list, my_invoices);
        }
        private void Musteri_brand_selection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Musteri_brand_selection.SelectedIndex >= 0)
            {
                InitializeSelection(Musteri_model_selection, ((Marka)Musteri_brand_selection.SelectedItem).modeller);
            }
            else
            {
                Musteri_model_selection.SelectedIndex = -1;
                Musteri_model_selection.Items.Clear();
            }
        }
        private void Musteri_model_selection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Musteri_model_selection.SelectedIndex >= 0)
            {
                InitializeSelection(Musteri_donanim_selection, ((Model)Musteri_model_selection.SelectedItem).donanimlar);
            }
            else
            {
                Musteri_donanim_selection.SelectedIndex = -1;
                Musteri_donanim_selection.Items.Clear();
            }
        }
        private void Musteri_donanim_selection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Musteri_donanim_selection.SelectedIndex >= 0)
            {
                InitializeSelection(Musteri_spare_part_selection, ((Donanim)Musteri_donanim_selection.SelectedItem).yedek_parcalar);
            }
            else
            {
                Musteri_spare_part_selection.SelectedIndex = -1;
                Musteri_spare_part_selection.Items.Clear();
            }
        }

        private void Musteri_spare_part_selection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Musteri_spare_part_selection.SelectedIndex >= 0)
            {
                Musteri_amount.Visible = true;
                label12.Visible = false;
            }
            else
            {
                label12.Visible = true;
                Musteri_amount.Value = 0;
                Musteri_amount.Visible = false;
            }
        }

        private void Musteri_add_to_cart_Click(object sender, EventArgs e)
        {
            if (Musteri_amount.Value != 0)
            {
                Invoice invoice = new Invoice();
                invoice.date = DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss_fff");
                invoice.amount = (int)Musteri_amount.Value;
                invoice.customer = CUser.id;
                invoice.part_name = ((Yedek_parca)Musteri_spare_part_selection.SelectedItem).isim;
                invoice.part_path = "Brands/" + ((Marka)Musteri_brand_selection.SelectedItem).isim + "/" + ((Model)Musteri_model_selection.SelectedItem).isim + "/" +
                   ((Donanim)Musteri_donanim_selection.SelectedItem).isim + "/" + invoice.part_name + ".txt";
                Setup_wizard.AddInvoice(invoice);
                Invoices.Add(invoice);
                Musteri_Shopping_list.Items.Add(invoice);
            }
            else
            {
                MessageBox.Show("Sipari� tamamlanamad�! L�tfen t�m alanlar� doldurdu�nuza emin olun.");
            }
        }

        private void Logout_button_Click(object sender, EventArgs e)
        {
            InitializePanels();
        }

        private void Delete_musteri_account_button_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Hesab�n�z� silmek istedi�inize eminmisiniz?", "Hesap Siliniyor", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                List<Invoice> deleteing = Invoices.Where(x => x.customer == CUser.id).ToList();
                for (int i = 0; i < deleteing.Count; i++)
                {
                    Invoices.Remove(deleteing[i]);
                    Setup_wizard.HandleInvoice(deleteing[i], "User deleted!");
                }
                Setup_wizard.Delete_user(CUser, users);
                InitializePanels();
            }
        }
        private void satici_panel_VisibleChanged(object sender, EventArgs e)
        {
            InitializeSelection(Satici_Brand_selection, Brands);
            InitializeSelection(Satici_invoices, Invoices);
        }

        private void Satici_Brand_selection_Leave(object sender, EventArgs e)
        {
            if (Satici_Brand_selection.Text != "")
            {

                if (Satici_Brand_selection.SelectedIndex == -1)
                {
                    if (MessageBox.Show($"Marka: {Satici_Brand_selection.Text} is not in the system!\nDo you want to add it?", "Marka ekleme"
                        , MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        Marka marka = new Marka(Satici_Brand_selection.Text);
                        Brands.Add(marka);
                        Satici_Brand_selection.Items.Add(marka);
                        Satici_Brand_selection.SelectedItem = marka;
                        Setup_wizard.AddBrand(marka);
                        Satici_Model_selection.SelectedIndex = -1;
                        Satici_Model_selection.Items.Clear();
                    }
                    else
                    {
                        Satici_Brand_selection.Text = "";
                    }
                }
                else
                {
                    InitializeSelection(Satici_Model_selection, ((Marka)Satici_Brand_selection.SelectedItem).modeller);
                }
            }
            else
            {
                Satici_Model_selection.SelectedIndex = -1;
                Satici_Model_selection.Items.Clear();
            }
        }

        private void Satici_Model_selection_Leave(object sender, EventArgs e)
        {
            if (Satici_Model_selection.Text != "")
            {

                if (Satici_Model_selection.SelectedIndex == -1)
                {
                    if (MessageBox.Show($"Model: {Satici_Model_selection.Text} is not in the system!\nDo you want to add it?", "Model ekleme"
                        , MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        Model model = new Model(Satici_Model_selection.Text);
                        ((Marka)Satici_Brand_selection.SelectedItem).modeller.Add(model);
                        Satici_Model_selection.Items.Add(model);
                        Satici_Model_selection.SelectedItem = model;
                        Setup_wizard.AddBrand((Marka)Satici_Brand_selection.SelectedItem);
                        Satici_donanim_selection.SelectedIndex = -1;
                        Satici_donanim_selection.Items.Clear();
                    }
                    else
                    {
                        Satici_Model_selection.Text = "";
                    }
                }
                else
                {
                    InitializeSelection(Satici_donanim_selection, ((Model)Satici_Model_selection.SelectedItem).donanimlar);
                }
            }
            else
            {
                Satici_donanim_selection.SelectedIndex = -1;
                Satici_donanim_selection.Items.Clear();
            }
        }

        private void Satici_donanim_selection_Leave(object sender, EventArgs e)
        {
            if (Satici_donanim_selection.Text != "")
            {

                if (Satici_donanim_selection.SelectedIndex == -1)
                {
                    if (MessageBox.Show($"Donanim: {Satici_donanim_selection.Text} is not in the system!\nDo you want to add it?", "Donanim ekleme"
                        , MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        Donanim donanim = new Donanim(Satici_donanim_selection.Text);
                        ((Model)Satici_Model_selection.SelectedItem).donanimlar.Add(donanim);
                        Satici_donanim_selection.Items.Add(donanim);
                        Satici_donanim_selection.SelectedItem = donanim;
                        Setup_wizard.AddBrand((Marka)Satici_Brand_selection.SelectedItem);
                        Satici_spare_parts_selection.SelectedIndex = -1;
                        Satici_spare_parts_selection.Items.Clear();
                    }
                    else
                    {
                        Satici_donanim_selection.Text = "";
                    }
                }
                else
                {
                    InitializeSelection(Satici_spare_parts_selection, ((Donanim)Satici_donanim_selection.SelectedItem).yedek_parcalar);
                }
            }
            else
            {
                Satici_spare_parts_selection.SelectedIndex = -1;
                Satici_spare_parts_selection.Items.Clear();
            }
        }

        private void Satici_spare_parts_selection_Leave(object sender, EventArgs e)
        {
            if (Satici_spare_parts_selection.Text != "")
            {

                if (Satici_spare_parts_selection.SelectedIndex == -1)
                {
                    if (MessageBox.Show($"Donanim: {Satici_spare_parts_selection.Text} is not in the system!\nDo you want to add it?", "Donanim ekleme"
                        , MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        Yedek_parca yedek_Parca = new Yedek_parca(Satici_spare_parts_selection.Text);
                        ((Donanim)Satici_donanim_selection.SelectedItem).yedek_parcalar.Add(yedek_Parca);
                        Satici_spare_parts_selection.Items.Add(yedek_Parca);
                        Satici_spare_parts_selection.SelectedItem = yedek_Parca;
                        Setup_wizard.AddBrand((Marka)Satici_Brand_selection.SelectedItem);

                        ineventory.Value = ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).inventory;
                        ineventory.Visible = true;
                        label18.Visible = true;
                    }
                    else
                    {
                        Satici_spare_parts_selection.Text = "";
                    }
                }
                else
                {
                    ineventory.Value = ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).inventory;
                    ineventory.Visible = true;
                    label18.Visible = true;
                }
            }
            else
            {
                ineventory.Value = -1;
                ineventory.Visible = false;
                label18.Visible = false;
            }
        }

        private void ineventory_Leave(object sender, EventArgs e)
        {
            if (ineventory.Value != ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).inventory)
            {
                if (MessageBox.Show("Bu par�an�n enveanter miktar�n� de�i�tirmek istedi�inize eminmisiniz?", "envanter miktar� de�i�tirme", MessageBoxButtons.OKCancel)
                    == DialogResult.OK)
                {
                    ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).inventory = (int)ineventory.Value;
                    Setup_wizard.AddBrand((Marka)Satici_Brand_selection.SelectedItem);
                }
                else
                {
                    ineventory.Value = ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).inventory;
                }
            }
        }

        private void enter_press(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                satici_panel.Focus();
            }
        }

        private void Delete_brand_Click(object sender, EventArgs e)
        {
            string path = "Brands/";
            string liste = "";
            if (Satici_Brand_selection.SelectedIndex > -1)
            {
                path += ((Marka)Satici_Brand_selection.SelectedItem).isim;
                liste = "Brands_list.txt";
                if (Satici_Model_selection.SelectedIndex > -1)
                {
                    path += "/" + ((Model)Satici_Model_selection.SelectedItem).isim;
                    liste = "model_list.txt";
                    if (Satici_donanim_selection.SelectedIndex > -1)
                    {
                        path += "/" + ((Donanim)Satici_donanim_selection.SelectedItem).isim;
                        liste = "donanim_list.txt";
                        if (Satici_spare_parts_selection.SelectedIndex > -1)
                        {
                            path += "/" + ((Yedek_parca)Satici_spare_parts_selection.SelectedItem).isim + ".txt";
                            liste = "spare_parts_list.txt";
                        }
                    }
                }
            }
            bool temp = true;
            foreach (Invoice invoice in Invoices)
            {
                if (invoice.part_path.StartsWith(path))
                {
                    MessageBox.Show("Bu par�alar� sipari� etmi� m��teriler var!\nSilmeden �nce bu sipari�leri cevaplay�n�z.", "Silinemiyor");
                    temp = false;
                    break;
                }
            }
            if (temp)
            {
                if (path.EndsWith(".txt"))
                {
                    File.Delete(path);
                }
                else
                {
                    Directory.Delete(path);
                }
                string path_temp = path.Substring(0, path.LastIndexOf("/") - 1);
                path_temp += liste;
                string name = path.Substring(path.LastIndexOf("/") + 1);
                List<string> strings = new List<string>();
                StreamReader reader = new StreamReader(path_temp);
                int n = Convert.ToInt32(reader.ReadLine());
                for (int i = 0; i < n; i++) { strings.Add(reader.ReadLine()); }
                reader.Close();
                strings.Remove(name);
                StreamWriter writer = new StreamWriter(path_temp);
                writer.AutoFlush = true;
                writer.WriteLine(Convert.ToString(n - 1));
                for (int i = 0; i < n - 1; i++) { writer.WriteLine(strings[i]); }
                writer.Close();
            }
        }

        private void Invoice_decline_Click(object sender, EventArgs e)
        {
            if (Satici_invoices.SelectedIndex > -1)
            {
                Setup_wizard.HandleInvoice(((Invoice)Satici_invoices.SelectedItem), "Sat�n alma olumsuz");
                Satici_invoices.Items.Remove(Satici_invoices.SelectedItem);
            }
        }

        private void Invoice_confirm_Click(object sender, EventArgs e)
        {
            if (Satici_invoices.SelectedIndex > -1)
            {
                Setup_wizard.HandleInvoice(((Invoice)Satici_invoices.SelectedItem), "Sat�n alma olumlu");
                Satici_invoices.Items.Remove(Satici_invoices.SelectedItem);
            }
        }

        private void Satici_delete_user_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Hesab�n�z� silmek istedi�inize eminmisiniz?", "Hesap Siliniyor", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Setup_wizard.Delete_user(CUser, users);
                InitializePanels();
            }
        }

        private void Yonetici_panel_VisibleChanged(object sender, EventArgs e)
        {
            InitializeSelection(comboBox1, users);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Setup_wizard.Delete_user(new Kullan�ci(comboBox1.SelectedText, "", "", "", ""), users);
            comboBox1.Items.Remove(comboBox1.SelectedText);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = "Brands/";
            if (comboBox2.SelectedIndex > -1) 
            {
                string list;
                if (comboBox2.SelectedValue == "Marka")
                {
                    list = "/Brands_list.txt";
                }
                else if (comboBox2.SelectedValue == "model") 
                {
                    list = "/model_list.txt";
                }
                else if (comboBox2.SelectedValue == "donan�m")
                {
                    list = "/donanim_list.txt";
                }
                else 
                {
                   list = "/spare_parts_list.txt";
                } 
                path += textBox1 + list == "/spare_parts_list.txt" ? ".txt" : "";
                bool temp = true;
                if (path.EndsWith(".txt"))
                {
                    if (!File.Exists(path)) 
                    {
                        temp = false;
                    }
                    else
                        File.Delete(path);
                }
                else
                {
                    if (!Directory.Exists(path)) 
                    {
                        temp = false;
                    }
                    else
                        Directory.Delete(path);
                }
                if (temp)
                {
                    string path_temp = path.Substring(0, path.LastIndexOf("/") - 1);
                    path_temp += list;
                    string name = path.Substring(path.LastIndexOf("/") + 1);
                    List<string> strings = new List<string>();
                    StreamReader reader = new StreamReader(path_temp);
                    int n = Convert.ToInt32(reader.ReadLine());
                    for (int i = 0; i < n; i++) { strings.Add(reader.ReadLine()); }
                    reader.Close();
                    strings.Remove(name);
                    StreamWriter writer = new StreamWriter(path_temp);
                    writer.AutoFlush = true;
                    writer.WriteLine(Convert.ToString(n - 1));
                    for (int i = 0; i < n - 1; i++) { writer.WriteLine(strings[i]); }
                    writer.Close();
                }
                else 
                    MessageBox.Show("B�yle bir ara� yok!"); 
            }
            else 
            {
                MessageBox.Show("L�tfen silmek istedi�iniz �eyin t�r�n� se�iniz!");
            }
        }
    }
}

